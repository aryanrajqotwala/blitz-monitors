# Location Code List

Use one of the following location codes. 
This is used for the free proxy service, so if you are using your own proxy, this will not be required.

Note that this is not the entire list of location codes, and some of these may not be available at certain times.
Please check the following website for a more up-to-date list of proxy locations: https://www.sslproxies.org/


Country | Code
--------|------
Argentina | AR
Australia | AU
Austria | AT
Bangladesh | BD
Brazil | BR
Cambodia | KH
Canada | CA
China | CN
Colombia | CO
Czech Republic | 
Denmark | DK
France | FR
Germany | DE
Hong Kong | HK
India | IN
Indonesia | ID
Iran | IR
Japan | JP
Malaysia | MY
Mexico | MX
Nepal | NP
Netherlands | NL
Philippines | PH
Poland | PL
Romania | RO
Russian Federation | RU
Singapore | SG
Thailand | TH
Turkey | TR
Ukraine | UA
United Kingdom | GB
United States | US
